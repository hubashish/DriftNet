# Light Mode

- bg-primary bg-coolGray-50
- bg-secondary bg-white
- text-primary text-slate-900
- text-secondary text-slate-500
- text-accent aka-blue

# Dark Mode

- bg-primary bg-slate-900
- bg-secondary bg-slate-800
- text-primary text-white
- text-secondary text-slate-400
- text-accent aka-blue
