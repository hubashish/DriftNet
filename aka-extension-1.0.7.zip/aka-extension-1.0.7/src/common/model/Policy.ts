export type Policy = {
  host: string;
  accept: string;
  type: string;
  conditions: { kinds: [] };
  created_at: number;
};
